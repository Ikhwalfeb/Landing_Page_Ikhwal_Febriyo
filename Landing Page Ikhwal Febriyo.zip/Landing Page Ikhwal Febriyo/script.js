function handleGetFormData() {
    const formData = {
        name: document.getElementById("name").value,
        city: document.getElementById("city").value,
        email: document.getElementById("email").value,
        zipCode: document.getElementById("zip-code").value,
        pesan: document.getElementById("pesan").value,
        status: document.getElementById("status").checked
    };
    return formData;
}

function isNumber(inputString) {
    return !isNaN(inputString);
}

function checkboxIsChecked() {
    const statusCheckbox = document.getElementById("status");
    return statusCheckbox.checked;
}

function validateFormData(formData) {
    if (
        formData.name &&
        formData.email &&
        formData.city &&
        formData.zipCode &&
        isNumber(formData.zipCode) &&
        checkboxIsChecked(formData.status)
    ){
        return true
    } else {
        return false
    }
}

function submit() {
    const formData = handleGetFormData();
    const warningDiv = document.getElementById("warning");
    if (!validateFormData(formData)) {
        warningDiv.textContent = "Periksa form anda sekali lagi";
    } else {
        warningDiv.textContent = "";
        
        console.log("Data yang akan dikirim:", formData);
        document.getElementById("form").reset();
    }
}
document.getElementById("form").addEventListener("submit", (event) => {
    event.preventDefault();
    submit();
});